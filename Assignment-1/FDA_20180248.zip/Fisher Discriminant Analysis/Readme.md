***Fisher's Linear Discriminant Analysis***

BITS F464 : Machine Learning

Mudit Chaturvedi - 2018A7PS0248H
Ashna Swaika - 2018A7PS0027H
Rohan Sachan - 2018B3A70992H

Run FDA.py to execute the analysis and observe the plots.

Plots are given in a separate folder titled Plot.
