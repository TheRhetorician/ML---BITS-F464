# Perceptron

Mudit Chaturvedi - 2018A7PS0248H
Ashna Swaika - 2018A7PS0027H
Rohan Sachan - 2018B3A70992H

Percptron.py implements the basic perceptron algorithm over two datasets - dataset_LP_1.txt and dataset_LP_2.csv. 
Run percptron.py 
